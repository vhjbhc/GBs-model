#for DFT tensile 
# By Jinhao Zhang
import numpy as np
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import math

def fit_and_evaluate(x_data, y_data, func):
    popt = [0,0]
    popt, pcov = curve_fit(func, x_data, y_data)
    y_fit = func(x_data, *popt)
    r2 = r2_score(y_data, y_fit)

    print("Fitted parameters:", popt)
    print("R2 score:", r2)
    a1=float(popt[0])
    a2=float(popt[1])
    print(a1)
    print(a2)
    print(10*a1/a2/2.71828)
    with open("output.txt", "w") as f:
        f.write(str(a1) + "\n")
        f.write(str(a2) + "\n")
        f.write(str(10 * a1 / a2 / 2.71828) + "\n")



    return popt, r2

def exp_func(x, A, B):
    return A-A*(1+x/B)*np.exp(-x/B)
# return a-a*(1+x/b)*np.exp(-x/b)

#x_data = np.linspace(0, 4, 50)
#y_data = exp_func(x_data, 2.5, 1.3, 0.5) + 0.2 * np.random.normal(size=len(x_data))
x_data,y_data = np.loadtxt('data.txt', usecols=(0,1), unpack = True)
popt, r2 = fit_and_evaluate(x_data, y_data, exp_func)

# 绘制原始数据
plt.scatter(x_data, y_data, label='Original data', color='blue')

# 绘制拟合后的数据
y_fit = exp_func(x_data, *popt)
plt.plot(x_data, y_fit, label='Fitted function', color='red')

# 添加图例
plt.legend()
plt.xlabel('nm')
# 显示图像
plt.show()
